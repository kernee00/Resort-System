<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name ="viewreport" content="width=device-width, initial-scale =1.0">
    <title>Customer</title>
    <link rel="stylesheet" href="../Style/nav_bar.css">

</head>


<body>
   
        <div class="navBar">
                        
            	<h1 class ="logo">Resort<span>Reservation</span></h1>
           
                <ul>
                    <li><a href='customerMain.php'>Profile</a></li>
                    <li><a href='bookingMain.php'>Booking</a></li>

                    <li><a href='managePayment.php'> Payment</a></li>
                    <li><a href='customerHistory.php'>History</a></li>
                    <li><a href='../Login/logout.php'>Logout</a></li>
                   
          
                </ul>
           
        </div>

  
</body>
</html>